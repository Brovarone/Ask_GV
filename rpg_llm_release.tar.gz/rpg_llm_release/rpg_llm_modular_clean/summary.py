from __future__ import annotations
import os
from pathlib import Path
from typing import Any, Dict, List, Optional
from .defaults import DEFAULT_SUMMARY_MAX_CHARS, SUMMARY_PROMPT, SYSTEM_PROMPT
from .models import SourceDocument
from .retrieval import build_keyword_counter
from .utils import safe_json_loads, trim_text, write_text
from .providers.base import extract_gemini_text, extract_openai_like_text
from .providers.gemini import call_gemini_generate_content, call_gemini_generate_with_file_uri, call_gemini_upload_file
from .providers.openrouter import call_openrouter

def build_summary_corpus(documents: List[SourceDocument], max_chars: int = DEFAULT_SUMMARY_MAX_CHARS) -> str:
    blocks: List[str] = []
    current = 0
    for d in documents:
        block = f"\n\n# FILE: {d.path}\nTITLE: {d.title}\n\n{trim_text(d.content, 16000)}"
        if current + len(block) > max_chars:
            break
        blocks.append(block)
        current += len(block)
    return "".join(blocks).strip()

def generate_summary(provider: str, model: str, documents: List[SourceDocument], gemini_use_files: bool = False, work_dir: Optional[Path] = None) -> Dict[str, Any]:
    corpus = build_summary_corpus(documents)
    user_prompt = "Analizza il seguente corpus Markdown relativo a un gioco di ruolo tabletop e costruisci un summary tecnico.\n\n" + corpus
    if provider == "openrouter":
        api_key = os.getenv("OPENROUTER_API_KEY")
        if not api_key:
            raise RuntimeError("OPENROUTER_API_KEY non impostata")
        raw = call_openrouter(model, api_key, [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": user_prompt}], response_format={"type": "json_object"})
        return safe_json_loads(extract_openai_like_text(raw)) or {"summary_text": extract_openai_like_text(raw)}
    if provider == "gemini":
        api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise RuntimeError("GEMINI_API_KEY / GOOGLE_API_KEY non impostata")
        if gemini_use_files and work_dir is not None:
            consolidated = work_dir / "gemini_summary_corpus.md"
            write_text(consolidated, corpus)
            up = call_gemini_upload_file(api_key, consolidated, "text/markdown")
            file_uri = up.get("file", {}).get("uri") or up.get("uri")
            mime = up.get("file", {}).get("mimeType", "text/markdown")
            if file_uri:
                raw = call_gemini_generate_with_file_uri(model, api_key, SUMMARY_PROMPT, file_uri, mime, "Analizza il file allegato e restituisci JSON valido secondo lo schema richiesto.")
                return safe_json_loads(extract_gemini_text(raw)) or {"summary_text": extract_gemini_text(raw), "file_upload": up}
        raw = call_gemini_generate_content(model, api_key, SUMMARY_PROMPT, user_prompt)
        return safe_json_loads(extract_gemini_text(raw)) or {"summary_text": extract_gemini_text(raw)}
    raise RuntimeError(f"Provider summary non supportato: {provider}")

def fallback_summary(documents: List[SourceDocument], error: Exception) -> Dict[str, Any]:
    return {"summary_text": f"Summary automatica non disponibile: {error}", "keywords": list(build_keyword_counter(documents).keys())[:60], "ambiguities": []}
